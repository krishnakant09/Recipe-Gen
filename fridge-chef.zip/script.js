// =====================
// STATE
// =====================
let uploadedImageBase64 = null;
let selectedDiet = "any";
let savedRecipes = JSON.parse(localStorage.getItem("fridgechef_saved") || "[]");
let apiKey = localStorage.getItem("fridgechef_apikey") || "";

// =====================
// ELEMENTS
// =====================
const uploadArea = document.getElementById("uploadArea");
const uploadCard = document.getElementById("uploadCard");
const fileInput = document.getElementById("fileInput");
const uploadBtn = document.getElementById("uploadBtn");
const previewArea = document.getElementById("previewArea");
const previewImg = document.getElementById("previewImg");
const removeBtn = document.getElementById("removeBtn");
const generateBtn = document.getElementById("generateBtn");
const btnText = document.getElementById("btnText");
const loading = document.getElementById("loading");
const loadingText = document.getElementById("loadingText");
const ingredientsSec = document.getElementById("ingredientsSection");
const ingredientTags = document.getElementById("ingredientTags");
const recipesSec = document.getElementById("recipesSection");
const recipesGrid = document.getElementById("recipesGrid");
const savedBtn = document.getElementById("savedBtn");
const modalOverlay = document.getElementById("modalOverlay");
const modalClose = document.getElementById("modalClose");
const modalBody = document.getElementById("modalBody");
const themeToggle = document.getElementById("themeToggle");
const apiKeyOverlay = document.getElementById("apiKeyOverlay");
const apiKeyInput = document.getElementById("apiKeyInput");
const saveApiKey = document.getElementById("saveApiKey");

// =====================
// INIT
// =====================
if (apiKey) {
  apiKeyOverlay.style.display = "none";
} else {
  apiKeyOverlay.style.display = "flex";
}

// =====================
// API KEY SETUP
// =====================
saveApiKey.addEventListener("click", () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    apiKeyInput.style.borderColor = "#eb5757";
    return;
  }
  localStorage.setItem("fridgechef_apikey", key);
  apiKey = key;
  apiKeyOverlay.style.display = "none";
});

apiKeyInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveApiKey.click();
});

// =====================
// THEME TOGGLE
// =====================
themeToggle.addEventListener("click", () => {
  const isLight =
    document.documentElement.getAttribute("data-theme") === "light";
  document.documentElement.setAttribute("data-theme", isLight ? "" : "light");
  themeToggle.textContent = isLight ? "🌙" : "☀️";
});

// =====================
// FILE UPLOAD
// =====================
uploadBtn.addEventListener("click", () => fileInput.click());
uploadArea.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", (e) => {
  if (e.target.files[0]) handleFile(e.target.files[0]);
});

// Drag & Drop
uploadCard.addEventListener("dragover", (e) => {
  e.preventDefault();
  uploadCard.classList.add("drag-over");
});

uploadCard.addEventListener("dragleave", () => {
  uploadCard.classList.remove("drag-over");
});

uploadCard.addEventListener("drop", (e) => {
  e.preventDefault();
  uploadCard.classList.remove("drag-over");
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith("image/")) handleFile(file);
});

function handleFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    uploadedImageBase64 = e.target.result.split(",")[1];
    previewImg.src = e.target.result;
    uploadArea.style.display = "none";
    previewArea.style.display = "block";
    generateBtn.disabled = false;
  };
  reader.readAsDataURL(file);
}

removeBtn.addEventListener("click", () => {
  uploadedImageBase64 = null;
  fileInput.value = "";
  previewArea.style.display = "none";
  uploadArea.style.display = "block";
  generateBtn.disabled = true;
  ingredientsSec.style.display = "none";
  recipesSec.style.display = "none";
});

// =====================
// DIET FILTERS
// =====================
document.querySelectorAll(".filter-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document
      .querySelectorAll(".filter-btn")
      .forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    selectedDiet = btn.dataset.diet;
  });
});

// =====================
// GENERATE RECIPES
// =====================
const loadingMessages = [
  "Scanning your ingredients...",
  "Thinking like a chef...",
  "Crafting your recipes...",
  "Almost ready to cook! 🍳",
];

generateBtn.addEventListener("click", async () => {
  if (!uploadedImageBase64) return;
  if (!apiKey) {
    apiKeyOverlay.style.display = "flex";
    return;
  }

  // Show loading
  generateBtn.disabled = true;
  loading.style.display = "block";
  ingredientsSec.style.display = "none";
  recipesSec.style.display = "none";

  let msgIndex = 0;
  loadingText.textContent = loadingMessages[0];
  const msgInterval = setInterval(() => {
    msgIndex = (msgIndex + 1) % loadingMessages.length;
    loadingText.textContent = loadingMessages[msgIndex];
  }, 1800);

  const dietNote =
    selectedDiet !== "any" ? `All recipes MUST be ${selectedDiet}.` : "";

  const prompt = `You are a professional chef AI. Analyze this fridge/ingredients photo and respond ONLY with a valid JSON object, no markdown, no backticks, no explanation.

${dietNote}

Return this exact structure:
{
  "ingredients": ["ingredient1", "ingredient2", ...],
  "recipes": [
    {
      "emoji": "🍜",
      "name": "Recipe Name",
      "time": "20 mins",
      "difficulty": "Easy",
      "ingredients": ["item1", "item2"],
      "steps": ["Step 1 description", "Step 2 description", "Step 3 description"],
      "nutrition": { "calories": "320", "protein": "18g", "carbs": "42g" }
    }
  ]
}

Generate exactly 3 recipes. Steps should be clear and concise (1 sentence each). Ingredients list should be specific. Emojis should match the dish.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  inline_data: {
                    mime_type: "image/jpeg",
                    data: uploadedImageBase64,
                  },
                },
                { text: prompt },
              ],
            },
          ],
          generationConfig: { temperature: 0.7, maxOutputTokens: 2048 },
        }),
      },
    );

    const data = await response.json();

    if (data.error) {
      throw new Error(data.error.message || "API error");
    }

    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    clearInterval(msgInterval);
    loading.style.display = "none";

    renderIngredients(parsed.ingredients || []);
    renderRecipes(parsed.recipes || []);
    generateBtn.disabled = false;
  } catch (err) {
    clearInterval(msgInterval);
    loading.style.display = "none";
    generateBtn.disabled = false;
    alert(
      "Something went wrong: " +
        err.message +
        "\n\nCheck your API key or try again.",
    );
  }
});

// =====================
// RENDER INGREDIENTS
// =====================
function renderIngredients(ingredients) {
  ingredientTags.innerHTML = "";
  ingredients.forEach((ing) => {
    const tag = document.createElement("div");
    tag.className = "ingredient-tag";
    tag.textContent = ing;
    ingredientTags.appendChild(tag);
  });
  ingredientsSec.style.display = "block";
  ingredientsSec.scrollIntoView({ behavior: "smooth", block: "start" });
}

// =====================
// RENDER RECIPES
// =====================
function renderRecipes(recipes) {
  recipesGrid.innerHTML = "";
  recipes.forEach((recipe, index) => {
    const isSaved = savedRecipes.some((r) => r.name === recipe.name);
    const card = document.createElement("div");
    card.className = "recipe-card";
    card.style.animationDelay = `${index * 0.1}s`;
    card.innerHTML = `
      <div class="recipe-header">
        <div class="recipe-emoji">${recipe.emoji || "🍽️"}</div>
        <div class="recipe-meta">
          <div class="recipe-name">${recipe.name}</div>
          <div class="recipe-badges">
            <span class="badge badge-time">⏱ ${recipe.time}</span>
            <span class="badge badge-diff">${recipe.difficulty}</span>
          </div>
        </div>
        <button class="save-btn" data-index="${index}" title="Save recipe">
          ${isSaved ? "❤️" : "🤍"}
        </button>
      </div>
      <div class="recipe-body">
        <div class="recipe-section-title">Ingredients</div>
        <div class="recipe-ingredients">
          ${recipe.ingredients.map((i) => `<span class="ing-chip">${i}</span>`).join("")}
        </div>
        <div class="recipe-section-title">Steps</div>
        <ol class="recipe-steps">
          ${recipe.steps
            .map(
              (step, i) => `
            <li>
              <span class="step-num">${i + 1}</span>
              <span>${step}</span>
            </li>
          `,
            )
            .join("")}
        </ol>
        ${
          recipe.nutrition
            ? `
        <div class="nutrition-row">
          <div class="nutrition-item">
            <span class="nutrition-value">${recipe.nutrition.calories}</span>
            <span class="nutrition-label">Calories</span>
          </div>
          <div class="nutrition-item">
            <span class="nutrition-value">${recipe.nutrition.protein}</span>
            <span class="nutrition-label">Protein</span>
          </div>
          <div class="nutrition-item">
            <span class="nutrition-value">${recipe.nutrition.carbs}</span>
            <span class="nutrition-label">Carbs</span>
          </div>
        </div>`
            : ""
        }
      </div>
    `;
    recipesGrid.appendChild(card);

    // Save button
    card.querySelector(".save-btn").addEventListener("click", function () {
      toggleSave(recipe, this);
    });
  });

  recipesSec.style.display = "block";
}

// =====================
// SAVE / UNSAVE
// =====================
function toggleSave(recipe, btn) {
  const existingIndex = savedRecipes.findIndex((r) => r.name === recipe.name);
  if (existingIndex === -1) {
    savedRecipes.push(recipe);
    btn.textContent = "❤️";
  } else {
    savedRecipes.splice(existingIndex, 1);
    btn.textContent = "🤍";
  }
  localStorage.setItem("fridgechef_saved", JSON.stringify(savedRecipes));
}

// =====================
// SAVED RECIPES MODAL
// =====================
savedBtn.addEventListener("click", () => {
  renderSavedModal();
  modalOverlay.style.display = "flex";
});

modalClose.addEventListener("click", () => {
  modalOverlay.style.display = "none";
});

modalOverlay.addEventListener("click", (e) => {
  if (e.target === modalOverlay) modalOverlay.style.display = "none";
});

function renderSavedModal() {
  if (savedRecipes.length === 0) {
    modalBody.innerHTML = `<div class="empty-saved">❤️<br /><br />No saved recipes yet.<br />Generate some and tap 🤍 to save!</div>`;
    return;
  }
  modalBody.innerHTML = savedRecipes
    .map(
      (r) => `
    <div class="saved-item">
      <div class="saved-item-emoji">${r.emoji || "🍽️"}</div>
      <div>
        <div class="saved-item-name">${r.name}</div>
        <div class="saved-item-sub">⏱ ${r.time} &nbsp;|&nbsp; ${r.difficulty}</div>
      </div>
    </div>
  `,
    )
    .join("");
}
